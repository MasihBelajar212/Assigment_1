#include<stdio.h>

int main()
{
	char nama[1000];
	int jumlah;
	int thn_lalu;
	int thn_ini;
	
	int total;
	
	int banyak;
	
	scanf("%d", &banyak);
	
	for(int i = 1 ; i<= banyak ; i++)
	{
		
	scanf("%s", &nama);
	scanf("%d %d", &thn_ini, &thn_lalu);
//	scanf("%d", &thn_lalu);
	
	
	printf("%d. %s", i,nama);
	
	jumlah = thn_ini + thn_lalu;
	printf(" %d Jumlah", jumlah);
	
	total = thn_ini - thn_lalu;
	if(total > 0)
	{
		printf(" %d Untung\n", total);
	}
	else
	{
		total = total * -1;
		printf(" %d Rugi\n", total);
	}
	
	
	}
	
	return 0;
}
