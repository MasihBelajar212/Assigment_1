#include<stdio.h>
#include<windows.h>

int main()
{
	int num1;
	int num2;
	int choice;
	
	int Total;

	
	printf("Add Integer 1 :");
	scanf("%d", &num1);
	printf("Add Integer 2 :");
	scanf("%d", &num2);

	do
	{
	printf("1.Plus the Integer\n");
	printf("2.Minus the Integer\n");
	printf("3.Multiply the Integer\n");
	printf("4.Divided the Integer\n");
	printf("Pilihlah angka dari 1-4 :");
	scanf("%d", &choice);
	
		if(choice == 1)
		{
			Total = num1 + num2;
			
			printf("\n%d",Total);
			break;
		}
		else if(choice == 2)
		{
			Total = num1 - num2;
			
			printf("\n%d", Total);
			break;
		}
		else if(choice == 3)
		{
			Total = num1 * num2;
			
			printf("\n%d", Total);
			break;
		}
		else if(choice == 4)
		{
			Total =num1/num2;
			
			printf("\n%d", Total);
			break;
		}
		else
		{
			printf("Angkanya harus 1-4 ok\n");
			printf("Press Enter\n");
			getchar();
			getchar();
		}
	}
	while(choice > 4);
	
	return 0;
}
